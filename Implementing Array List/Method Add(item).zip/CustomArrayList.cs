﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ImplementArrayList
{
    public class CustomArrayList
    {
        private object[] arr;
        private int count;
        public int Count
        {
            get => count;
            private set { count = value; }
        }

        private static readonly int INITIAL_CAPACITY = 4;
        public CustomArrayList()
        {
            arr = new object[INITIAL_CAPACITY];
            count = 0;
        }
        public void Add(object item)
        {
            Insert(count, item);
        }
        public bool Contains(object item)
        {
            int currentIndex = IndexOf(item);
            if(currentIndex == -1)
            {
                return false;
            }
            return true;
        }
        public object Remove(int index)
        {
            if (index >= count || index < 0)
            {
                throw new ArgumentOutOfRangeException("Invalid index: " + index);
            }
            object item = arr[index];

            arr[index] = null;

            for(int i = index; i < arr.Length - 1; i++)
            {
                arr[i] = arr[i + 1];
            }
            arr[count - 1] = null;
            count--;

            if(count < arr.Length / 2)
            {
                Shrink();
            }
            return item;
        }
        public void Shrink()
        {
            object[] copy = new object[arr.Length / 2];
            Array.Copy(arr, copy, copy.Length);
            arr = copy;
        }
            public int Remove(object item)
        {
            int index = IndexOf(item);
            if (index == -1)
            {
               return index;
            }
            Remove(index);

            return index;
        }
        public void Insert(int index, object item)
        {
            if (count == arr.Length)
            {
                Resize();
            }

            for (int i = arr.Length - 1; i < index; i++)
            {
                arr[i] = arr[i - 1];
            }
            arr[index] = item;
            count++;
        }
        public int IndexOf(object item)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].Equals(item))
                {
                    return i;
                }               
            }
            return -1;
        }
        public void Clear()
        {
            arr = new object[INITIAL_CAPACITY];
            count = 0;
        }
        public object this[int index]
        {
            get
            {
                if (index >= count || index < 0)
                {
                    throw new ArgumentOutOfRangeException("Invalid index: " + index);
                }
                    return arr[index];
            }
            set
            {
                    if (index >= count || index < 0)
                    {
                        throw new ArgumentOutOfRangeException("Invalid index: " + index);
                    }

                    arr[index] = value;
            }
        }
        public void Resize()
        {
            object[] copy = new object[arr.Length * 2];
            Array.Copy(arr, copy, copy.Length);
            arr = copy;
        }
    }
}
