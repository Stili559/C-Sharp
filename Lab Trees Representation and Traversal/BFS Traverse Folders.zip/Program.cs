﻿using System;
using System.IO;

namespace BFSTraverseFolderss
{
    class Program
    {
        private static void BFSTraverseFolders(DirectoryInfo directory, string spaces)
        {
            Console.WriteLine(spaces + directory.FullName);
            DirectoryInfo[] childrens = directory.GetDirectories();
            foreach (DirectoryInfo child in childrens)
            BFSTraverseFolders(child, spaces + " ");
        }
        static void BFSTraverseFolders(string Path)
        {
            BFSTraverseFolders(new DirectoryInfo(Path), string.Empty);
        }
        static void Main()
        {
            //BFSTraverseFolders(@"C:\Windows\assembly");
        }
    }
}
