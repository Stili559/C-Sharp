﻿using System;
using System.Collections.Generic;
using System.IO;

namespace BFSTraverseFolders
{
    class Program
    {
        private static void TraverseDir(DirectoryInfo dir, string spaces)
        {
            Console.WriteLine(spaces + dir.FullName);
            DirectoryInfo[] children = dir.GetDirectories();
            foreach (DirectoryInfo child in children)
                TraverseDir(child, spaces + " ");

        }
        static void TraverseDir(string directoryPath)
        {
            TraverseDir(new DirectoryInfo(directoryPath), string.Empty);
        }
        static void Main()
        {
            TraverseDir(@"C:\Windows\assembly");
        }
    }
}
