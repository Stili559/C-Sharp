﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Arcade
{

    public partial class Theballelvel3 : UserControl
    {
        public int speed_l = 4;
        public int speed_t = 4;
        public int scorses = 0;
        public Theballelvel3()
        {
            InitializeComponent();
        }

        private void Tim_Tick(object sender, EventArgs e)
        {
            Wall.Left = Cursor.Position.X - 500;

            Balll.Left += speed_l;
            Balll.Top += speed_t;
            Tm.Text = "Score:" + scorses;

            if (Balll.Bottom >= Wall.Top && Balll.Bottom <= Wall.Bottom && Balll.Left >= Wall.Left && Balll.Right <= Wall.Right)
            {
                speed_t += 2;
                speed_l += 2;
                speed_t = -speed_t;
            }

            if (Balll.Left < 0 || Balll.Left > 800)
            {
                speed_l = -speed_l;
            }
            if (Balll.Top < 0 || Balll.Top > 800)
            {
                speed_t = -speed_t;
            }
            if (Balll.Bottom >= 550)
            {
                Tim.Stop();
                Tm.Text = "Game over";
            }
            if (scorses == 30)
            {
                Tim.Stop();
                Tm.Text = "You win";
            }

            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "Boxes")
                {
                    if (Balll.Bounds.IntersectsWith(x.Bounds))
                    {
                        scorses += 1;

                        speed_t = -speed_t;

                        this.Controls.Remove(x);
                    }
                }
            }
        }

        private void Theballelvel3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.P)
            {
                Tim.Start();
            }
        }

        private void Wall_Click(object sender, EventArgs e)
        {

        }
    }
}

