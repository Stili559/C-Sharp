﻿
namespace Arcade
{
    partial class TheDice
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TheDice));
            this.Dice1 = new System.Windows.Forms.PictureBox();
            this.Dice2 = new System.Windows.Forms.PictureBox();
            this.Dice3 = new System.Windows.Forms.PictureBox();
            this.Dice4 = new System.Windows.Forms.PictureBox();
            this.Dice5 = new System.Windows.Forms.PictureBox();
            this.Dice6 = new System.Windows.Forms.PictureBox();
            this.Boxd1 = new System.Windows.Forms.PictureBox();
            this.Boxd2 = new System.Windows.Forms.PictureBox();
            this.Boxd3 = new System.Windows.Forms.PictureBox();
            this.StartButtonn = new System.Windows.Forms.Button();
            this.TT = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.Dice1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Boxd1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Boxd2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Boxd3)).BeginInit();
            this.SuspendLayout();
            // 
            // Dice1
            // 
            this.Dice1.Image = ((System.Drawing.Image)(resources.GetObject("Dice1.Image")));
            this.Dice1.Location = new System.Drawing.Point(41, 34);
            this.Dice1.Name = "Dice1";
            this.Dice1.Size = new System.Drawing.Size(120, 106);
            this.Dice1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Dice1.TabIndex = 0;
            this.Dice1.TabStop = false;
            this.Dice1.Visible = false;
            // 
            // Dice2
            // 
            this.Dice2.Image = ((System.Drawing.Image)(resources.GetObject("Dice2.Image")));
            this.Dice2.Location = new System.Drawing.Point(167, 34);
            this.Dice2.Name = "Dice2";
            this.Dice2.Size = new System.Drawing.Size(120, 106);
            this.Dice2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Dice2.TabIndex = 1;
            this.Dice2.TabStop = false;
            this.Dice2.Visible = false;
            // 
            // Dice3
            // 
            this.Dice3.Image = global::Arcade.Properties.Resources.images__3_;
            this.Dice3.Location = new System.Drawing.Point(293, 34);
            this.Dice3.Name = "Dice3";
            this.Dice3.Size = new System.Drawing.Size(120, 106);
            this.Dice3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Dice3.TabIndex = 2;
            this.Dice3.TabStop = false;
            this.Dice3.Visible = false;
            // 
            // Dice4
            // 
            this.Dice4.Image = ((System.Drawing.Image)(resources.GetObject("Dice4.Image")));
            this.Dice4.Location = new System.Drawing.Point(419, 34);
            this.Dice4.Name = "Dice4";
            this.Dice4.Size = new System.Drawing.Size(120, 106);
            this.Dice4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Dice4.TabIndex = 3;
            this.Dice4.TabStop = false;
            this.Dice4.Visible = false;
            // 
            // Dice5
            // 
            this.Dice5.Image = ((System.Drawing.Image)(resources.GetObject("Dice5.Image")));
            this.Dice5.Location = new System.Drawing.Point(545, 34);
            this.Dice5.Name = "Dice5";
            this.Dice5.Size = new System.Drawing.Size(120, 106);
            this.Dice5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Dice5.TabIndex = 4;
            this.Dice5.TabStop = false;
            this.Dice5.Visible = false;
            // 
            // Dice6
            // 
            this.Dice6.Image = global::Arcade.Properties.Resources.images__6_;
            this.Dice6.Location = new System.Drawing.Point(671, 34);
            this.Dice6.Name = "Dice6";
            this.Dice6.Size = new System.Drawing.Size(120, 106);
            this.Dice6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Dice6.TabIndex = 5;
            this.Dice6.TabStop = false;
            this.Dice6.Visible = false;
            // 
            // Boxd1
            // 
            this.Boxd1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Boxd1.Location = new System.Drawing.Point(41, 146);
            this.Boxd1.Name = "Boxd1";
            this.Boxd1.Size = new System.Drawing.Size(246, 257);
            this.Boxd1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Boxd1.TabIndex = 6;
            this.Boxd1.TabStop = false;
            // 
            // Boxd2
            // 
            this.Boxd2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Boxd2.Location = new System.Drawing.Point(293, 146);
            this.Boxd2.Name = "Boxd2";
            this.Boxd2.Size = new System.Drawing.Size(246, 257);
            this.Boxd2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Boxd2.TabIndex = 7;
            this.Boxd2.TabStop = false;
            // 
            // Boxd3
            // 
            this.Boxd3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Boxd3.Location = new System.Drawing.Point(545, 146);
            this.Boxd3.Name = "Boxd3";
            this.Boxd3.Size = new System.Drawing.Size(246, 257);
            this.Boxd3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Boxd3.TabIndex = 8;
            this.Boxd3.TabStop = false;
            // 
            // StartButtonn
            // 
            this.StartButtonn.Location = new System.Drawing.Point(293, 409);
            this.StartButtonn.Name = "StartButtonn";
            this.StartButtonn.Size = new System.Drawing.Size(247, 76);
            this.StartButtonn.TabIndex = 10;
            this.StartButtonn.Text = "Start";
            this.StartButtonn.UseVisualStyleBackColor = true;
            this.StartButtonn.Click += new System.EventHandler(this.StartButtonn_Click);
            // 
            // TT
            // 
            this.TT.AutoSize = true;
            this.TT.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TT.Location = new System.Drawing.Point(855, 34);
            this.TT.Name = "TT";
            this.TT.Size = new System.Drawing.Size(32, 37);
            this.TT.TabIndex = 11;
            this.TT.Text = "0";
            // 
            // TheDice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.TT);
            this.Controls.Add(this.StartButtonn);
            this.Controls.Add(this.Boxd3);
            this.Controls.Add(this.Boxd2);
            this.Controls.Add(this.Boxd1);
            this.Controls.Add(this.Dice6);
            this.Controls.Add(this.Dice5);
            this.Controls.Add(this.Dice4);
            this.Controls.Add(this.Dice3);
            this.Controls.Add(this.Dice2);
            this.Controls.Add(this.Dice1);
            this.Name = "TheDice";
            this.Size = new System.Drawing.Size(973, 556);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TheDice_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.Dice1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dice6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Boxd1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Boxd2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Boxd3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Dice1;
        private System.Windows.Forms.PictureBox Dice2;
        private System.Windows.Forms.PictureBox Dice3;
        private System.Windows.Forms.PictureBox Dice4;
        private System.Windows.Forms.PictureBox Dice5;
        private System.Windows.Forms.PictureBox Dice6;
        private System.Windows.Forms.PictureBox Boxd1;
        private System.Windows.Forms.PictureBox Boxd2;
        private System.Windows.Forms.PictureBox Boxd3;
        private System.Windows.Forms.Button StartButtonn;
        private System.Windows.Forms.Label TT;
        private System.Windows.Forms.Timer timer1;
    }
}
