﻿
namespace Arcade
{
    partial class Car
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Car));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Carr = new System.Windows.Forms.PictureBox();
            this.Dumpster2 = new System.Windows.Forms.PictureBox();
            this.Dumpster1 = new System.Windows.Forms.PictureBox();
            this.Menu = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Carr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dumpster2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dumpster1)).BeginInit();
            this.Menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Carr
            // 
            this.Carr.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Carr.Image = ((System.Drawing.Image)(resources.GetObject("Carr.Image")));
            this.Carr.Location = new System.Drawing.Point(74, 236);
            this.Carr.Name = "Carr";
            this.Carr.Size = new System.Drawing.Size(207, 135);
            this.Carr.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Carr.TabIndex = 5;
            this.Carr.TabStop = false;
            this.Carr.Click += new System.EventHandler(this.Carr_Click);
            // 
            // Dumpster2
            // 
            this.Dumpster2.Image = ((System.Drawing.Image)(resources.GetObject("Dumpster2.Image")));
            this.Dumpster2.Location = new System.Drawing.Point(217, 407);
            this.Dumpster2.Name = "Dumpster2";
            this.Dumpster2.Size = new System.Drawing.Size(112, 174);
            this.Dumpster2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Dumpster2.TabIndex = 6;
            this.Dumpster2.TabStop = false;
            this.Dumpster2.Click += new System.EventHandler(this.Dumpster2_Click);
            // 
            // Dumpster1
            // 
            this.Dumpster1.Image = ((System.Drawing.Image)(resources.GetObject("Dumpster1.Image")));
            this.Dumpster1.Location = new System.Drawing.Point(841, 159);
            this.Dumpster1.Name = "Dumpster1";
            this.Dumpster1.Size = new System.Drawing.Size(103, 147);
            this.Dumpster1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Dumpster1.TabIndex = 7;
            this.Dumpster1.TabStop = false;
            this.Dumpster1.Click += new System.EventHandler(this.Dumpster1_Click);
            // 
            // Menu
            // 
            this.Menu.Controls.Add(this.label2);
            this.Menu.Controls.Add(this.label1);
            this.Menu.Location = new System.Drawing.Point(287, 115);
            this.Menu.Name = "Menu";
            this.Menu.Size = new System.Drawing.Size(576, 339);
            this.Menu.TabIndex = 8;
            this.Menu.TabStop = false;
            this.Menu.Text = "Menu";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(198, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "Game Over";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(254, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 30);
            this.label2.TabIndex = 1;
            this.label2.Text = "Restart";
            this.label2.Click += new System.EventHandler(this.Res_Click);
            // 
            // Car
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.Controls.Add(this.Menu);
            this.Controls.Add(this.Dumpster1);
            this.Controls.Add(this.Dumpster2);
            this.Controls.Add(this.Carr);
            this.Name = "Car";
            this.Size = new System.Drawing.Size(1151, 601);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Car_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Car_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.Carr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dumpster2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dumpster1)).EndInit();
            this.Menu.ResumeLayout(false);
            this.Menu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox Carr;
        private System.Windows.Forms.PictureBox Dumpster2;
        private System.Windows.Forms.PictureBox Dumpster1;
        private System.Windows.Forms.GroupBox Menu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}
