﻿
namespace Arcade
{
    partial class Theball
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ball = new System.Windows.Forms.PictureBox();
            this.hit = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.score = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Rest = new System.Windows.Forms.Label();
            this.Me = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.ball)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hit)).BeginInit();
            this.Me.SuspendLayout();
            this.SuspendLayout();
            // 
            // ball
            // 
            this.ball.BackColor = System.Drawing.SystemColors.Desktop;
            this.ball.Location = new System.Drawing.Point(392, 159);
            this.ball.Name = "ball";
            this.ball.Size = new System.Drawing.Size(23, 24);
            this.ball.TabIndex = 0;
            this.ball.TabStop = false;
            this.ball.Click += new System.EventHandler(this.ball_Click);
            // 
            // hit
            // 
            this.hit.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.hit.Location = new System.Drawing.Point(367, 339);
            this.hit.Name = "hit";
            this.hit.Size = new System.Drawing.Size(158, 28);
            this.hit.TabIndex = 1;
            this.hit.TabStop = false;
            this.hit.Click += new System.EventHandler(this.hit_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 25;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // score
            // 
            this.score.AutoSize = true;
            this.score.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.score.Location = new System.Drawing.Point(17, 16);
            this.score.Name = "score";
            this.score.Size = new System.Drawing.Size(91, 32);
            this.score.TabIndex = 2;
            this.score.Text = "Score:0";
            this.score.Click += new System.EventHandler(this.label1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(249, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 43);
            this.label1.TabIndex = 2;
            this.label1.Text = "Game Over";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Rest
            // 
            this.Rest.AutoSize = true;
            this.Rest.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Rest.Location = new System.Drawing.Point(305, 161);
            this.Rest.Name = "Rest";
            this.Rest.Size = new System.Drawing.Size(77, 30);
            this.Rest.TabIndex = 3;
            this.Rest.Text = "Restart";
            this.Rest.Click += new System.EventHandler(this.Rest_Click);
            // 
            // Me
            // 
            this.Me.Controls.Add(this.Rest);
            this.Me.Controls.Add(this.label1);
            this.Me.Location = new System.Drawing.Point(177, 55);
            this.Me.Name = "Me";
            this.Me.Size = new System.Drawing.Size(668, 377);
            this.Me.TabIndex = 3;
            this.Me.TabStop = false;
            this.Me.Text = "Menu";
            // 
            // Theball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.Controls.Add(this.Me);
            this.Controls.Add(this.score);
            this.Controls.Add(this.ball);
            this.Controls.Add(this.hit);
            this.Name = "Theball";
            this.Size = new System.Drawing.Size(995, 518);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Theball_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.ball)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hit)).EndInit();
            this.Me.ResumeLayout(false);
            this.Me.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox ball;
        private System.Windows.Forms.PictureBox hit;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label score;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Rest;
        private System.Windows.Forms.GroupBox Me;
    }
}
