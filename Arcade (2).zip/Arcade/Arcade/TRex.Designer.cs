﻿
namespace Arcade
{
    partial class TRex
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TRex));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Cactus1 = new System.Windows.Forms.PictureBox();
            this.Cactus2 = new System.Windows.Forms.PictureBox();
            this.rex = new System.Windows.Forms.PictureBox();
            this.Score = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Menuss = new System.Windows.Forms.GroupBox();
            this.Restarte = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cactus1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cactus2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rex)).BeginInit();
            this.Menuss.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 579);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1088, 26);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "Hits";
            // 
            // Cactus1
            // 
            this.Cactus1.Image = ((System.Drawing.Image)(resources.GetObject("Cactus1.Image")));
            this.Cactus1.Location = new System.Drawing.Point(444, 537);
            this.Cactus1.Name = "Cactus1";
            this.Cactus1.Size = new System.Drawing.Size(39, 53);
            this.Cactus1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cactus1.TabIndex = 1;
            this.Cactus1.TabStop = false;
            this.Cactus1.Tag = "Hits";
            // 
            // Cactus2
            // 
            this.Cactus2.Image = global::Arcade.Properties.Resources.Screenshot_2022_01_06_104802;
            this.Cactus2.Location = new System.Drawing.Point(703, 550);
            this.Cactus2.Name = "Cactus2";
            this.Cactus2.Size = new System.Drawing.Size(62, 40);
            this.Cactus2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cactus2.TabIndex = 2;
            this.Cactus2.TabStop = false;
            this.Cactus2.Tag = "Hits";
            // 
            // rex
            // 
            this.rex.Image = ((System.Drawing.Image)(resources.GetObject("rex.Image")));
            this.rex.Location = new System.Drawing.Point(102, 537);
            this.rex.Name = "rex";
            this.rex.Size = new System.Drawing.Size(58, 53);
            this.rex.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rex.TabIndex = 3;
            this.rex.TabStop = false;
            // 
            // Score
            // 
            this.Score.AutoSize = true;
            this.Score.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Score.Location = new System.Drawing.Point(3, 14);
            this.Score.Name = "Score";
            this.Score.Size = new System.Drawing.Size(80, 30);
            this.Score.TabIndex = 4;
            this.Score.Text = "Score:0";
            // 
            // timer1
            // 
            this.timer1.Interval = 20;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Menuss
            // 
            this.Menuss.Controls.Add(this.Restarte);
            this.Menuss.Controls.Add(this.label1);
            this.Menuss.Location = new System.Drawing.Point(308, 95);
            this.Menuss.Name = "Menuss";
            this.Menuss.Size = new System.Drawing.Size(513, 297);
            this.Menuss.TabIndex = 5;
            this.Menuss.TabStop = false;
            this.Menuss.Text = "Menu";
            // 
            // Restarte
            // 
            this.Restarte.AutoSize = true;
            this.Restarte.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Restarte.Location = new System.Drawing.Point(228, 150);
            this.Restarte.Name = "Restarte";
            this.Restarte.Size = new System.Drawing.Size(77, 30);
            this.Restarte.TabIndex = 5;
            this.Restarte.Text = "Restart";
            this.Restarte.Click += new System.EventHandler(this.Restarte_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(172, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "Game Over";
            // 
            // TRex
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Menu;
            this.Controls.Add(this.Menuss);
            this.Controls.Add(this.Score);
            this.Controls.Add(this.rex);
            this.Controls.Add(this.Cactus2);
            this.Controls.Add(this.Cactus1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "TRex";
            this.Size = new System.Drawing.Size(1088, 605);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TRex_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TRex_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cactus1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cactus2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rex)).EndInit();
            this.Menuss.ResumeLayout(false);
            this.Menuss.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox Cactus1;
        private System.Windows.Forms.PictureBox Cactus2;
        private System.Windows.Forms.PictureBox rex;
        private System.Windows.Forms.Label Score;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox Menuss;
        private System.Windows.Forms.Label Restarte;
        private System.Windows.Forms.Label label1;
    }
}
