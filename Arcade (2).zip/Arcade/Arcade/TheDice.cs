﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Arcade
{
    public partial class TheDice : UserControl
    {
        int clicks = 0;
        public TheDice()
        {
            InitializeComponent();
        }

        private void StartButtonn_Click(object sender, EventArgs e)
        {
            clicks += 1;
            TT.Text = "Clicks: " + clicks;
            Random r = new Random();      

            int R = r.Next(0, 6);

            if(R == 0)
            {
                Boxd1.Image = Dice1.Image;
            }
            else if (R == 1)
            {
                Boxd1.Image = Dice2.Image;
            }
            else if (R == 2)
            {
                Boxd1.Image = Dice3.Image;
            }
            else if (R == 3)
            {
                Boxd1.Image = Dice4.Image;
            }
            else if (R == 4)
            {
                Boxd1.Image = Dice5.Image;
            }
            else if (R == 5)
            {
                Boxd1.Image = Dice6.Image;
            }

            int Rr = r.Next(0, 6);
            if (Rr == 0)
            {
                Boxd2.Image = Dice1.Image;
            }
            else if (Rr == 1)
            {
                Boxd2.Image = Dice2.Image;
            }
            else if (Rr == 2)
            {
                Boxd2.Image = Dice3.Image;
            }
            else if (Rr == 3)
            {
                Boxd2.Image = Dice4.Image;
            }
            else if (Rr == 4)
            {
                Boxd2.Image = Dice5.Image;
            }
            else if (Rr == 5)
            {
                Boxd2.Image = Dice6.Image;
            }

            int Rrr = r.Next(0, 6);
            if (Rrr == 0)
            {
                Boxd3.Image = Dice1.Image;
            }
            else if (Rrr == 1)
            {
                Boxd3.Image = Dice2.Image;
            }
            else if (Rrr == 2)
            {
                Boxd3.Image = Dice3.Image;
            }
            else if (Rrr == 3)
            {
                Boxd3.Image = Dice4.Image;
            }
            else if (Rrr == 4)
            {
                Boxd3.Image = Dice5.Image;
            }
            else if (Rrr == 5)
            {
                Boxd3.Image = Dice6.Image;
            }         
        }

        private void TheDice_KeyDown(object sender, KeyEventArgs e)
        {          
        }
    }
}
