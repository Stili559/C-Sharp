﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Arcade
{
    public partial class TRex : UserControl
    {
        bool jump = false;
        int Rspeed = 10;
        int gravity = 0;
        int Hspeed = 8;
        int score = 0;

        Random r = new Random();     

        public TRex()
        {
            InitializeComponent();
            Menuss.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            rex.Top += Rspeed;        
            Cactus1.Left -= Hspeed;
            Cactus2.Left -= Hspeed;
            Score.Text = "Score: " + score;
       
            if (jump == true )
            {
                Rspeed = -10;
                gravity -= 1;
            }
            else
            {
                Rspeed = 10;
            }
    
            if (rex.Top > 531 && jump == false)
            {           
                rex.Top = 530;            
            }

            if (Cactus1.Left < -10)
            {
                Cactus1.Left = r.Next(300, 500);
                score++;
            }
            if (Cactus2.Left < -10)
            {
                Cactus2.Left = r.Next(800, 900);
                score++;
            }
            if (score >= 10)
            {
                Rspeed += 5;
            }
            if (rex.Bounds.IntersectsWith(Cactus1.Bounds) || rex.Bounds.IntersectsWith(Cactus2.Bounds))
            {
                Menuss.Show();
                timer1.Stop();
            }
        }

        private void TRex_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                jump = true;
            }
            else if (e.KeyCode == Keys.P)
            {
                timer1.Start();
            }

        }

        private void TRex_KeyUp(object sender, KeyEventArgs e)
        {
            if (jump == true)
            {
                jump = false;
            }
        }

        private void Restarte_Click(object sender, EventArgs e)
        {
            timer1.Start();
            Menuss.Hide();
            rex.Location = new Point(86, 202);
            score = 0;
        }
    }
}
