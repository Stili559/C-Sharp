﻿using rm.Trie;
using System;

namespace WordsWithPrefix
{
    class Program
    {
        static void Main(string[] args)
        {
            Trie trie = new Trie();     

            string[] words = Console.ReadLine().Split();

            string prefix = Console.ReadLine();

            if(prefix != "")
            {
                for (int i = 0; i < words.Length; i++)
                {
                    trie.AddWord(words[i]);
                }
            }
            
            Console.WriteLine(trie.Count());
            Console.WriteLine(trie.UniqueCount());
            Console.WriteLine(string.Join(", ", trie.GetWords()));
            Console.WriteLine(string.Join(", ", trie.GetWords(prefix)));
            trie.RemovePrefix(prefix);
            Console.WriteLine(string.Join(", ", trie.GetWords()));
        }
    }
}

